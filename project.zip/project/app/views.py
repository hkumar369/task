from django.shortcuts import redirect, render
from .models import Account_details,employ_details,task_details
# Create your views here.
def front(request):
    return render(request,"front.html")
def account(request):
    if request.method=="POST":        
        name=request.POST['name']
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        adminuser=Account_details(name=name,username=username,email=email,password=password)
        adminuser.save()
        empalis=employ_details.objects.all()
        return render(request,"list.html",{"lis":empalis,"btn":True})
    else:
        return render(request,"account.html")

def login(request):
    if request.method=="POST":
        global namee
        namee=request.POST['name']
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        adminch=Account_details.objects.all()
        for item in adminch:
            if password==item.password:        
                empuser=employ_details(name=namee,username=username,email=email,password=password)
                empuser.save()
                global a 
                a=item.password
                empalis=employ_details.objects.all()
                return render(request,"list.html",{"lis":empalis,"ass":True})
        return render(request,"password.html")
    else:
        return render(request,"login.html")

def task(request):
    if request.method == "POST":
        nameemp=request.POST['name']
        details=request.POST['detail']
        #deadline=request.POST['date']
        taskdet=task_details(name=nameemp,detail=details)
        #,deadline=deadline)
        taskdet.save()
        empalis=employ_details.objects.all()
        return render(request,"list.html",{"lis":empalis,"btn":True})
    else:    
        return render(request,"task.html")
def assignmentc(request):
    tasks=task_details.objects.all()
    for item in tasks:
        if namee==item.name:
            return render(request,"assignment.html",{"det":item.detail,"deadline":item.deadline,"ch":True})
    return render(request,"assignment.html",{"check":True})
